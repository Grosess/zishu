// Simple storage - persists between function calls but resets on redeploy
let storage = global.storage || { devices: {} };
global.storage = storage;

exports.handler = async (event, context) => {
  // Enable CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-API-Key',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  // Calculate metrics
  const devices = Object.values(storage.devices);
  const metrics = {
    total_users: devices.length,
    total_characters_learned: devices.reduce((sum, d) => sum + (d.characters || 0), 0),
    total_words_learned: devices.reduce((sum, d) => sum + (d.words || 0), 0),
    total_characters_practiced: devices.reduce((sum, d) => sum + (d.practiced || 0), 0),
    daily_active_users: devices.length, // Simplified
    last_updated: new Date().toISOString()
  };

  return {
    statusCode: 200,
    headers,
    body: JSON.stringify(metrics)
  };
};