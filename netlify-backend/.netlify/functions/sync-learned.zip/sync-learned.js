// Shared storage
let storage = global.storage || { devices: {} };
global.storage = storage;

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Device-ID',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { 
      statusCode: 405, 
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const data = JSON.parse(event.body);
    const { device_id, characters_count = 0, words_count = 0, total_practiced = 0 } = data;

    if (!device_id) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'device_id required' })
      };
    }

    // Update device data
    storage.devices[device_id] = {
      device_id,
      characters: characters_count,
      words: words_count,
      practiced: total_practiced,
      last_seen: new Date().toISOString()
    };

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ 
        success: true,
        sync_id: `sync_${Date.now()}`,
        timestamp: new Date().toISOString()
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};